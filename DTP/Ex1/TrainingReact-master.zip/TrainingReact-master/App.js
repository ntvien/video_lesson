/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import { Text, View, StyleSheet} from 'react-native';
import BreadScrumb from './src/Components/BreadScrumb/breadscrumb';
import NavBar from './src/Components/NavBar/navbar';


// class newClass extends Component{
  
//   render(){
//     return <View>

//     </View>
//   }
// }
const AppStyle = new StyleSheet.create({
  container: {
    flex:1,
    backgroundColor: 'pink'
  }
});

const App = ()  => {

  return (
    <View style={AppStyle.container}>
        <NavBar></NavBar>
        <BreadScrumb></BreadScrumb>
    </View>
  );
};

export default App;
