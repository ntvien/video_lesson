const BackIcon = require("./back_icon.png");
const HatIcon = require("./hat_icon.png");
const LetterIcon = require("./letter_icon.png");
const BookDetailIcon = require("./bookdetail_icon.png");
const ArrowRightIcon = require("./arrow_right_icon.png");

export default {
    BackIcon,
    HatIcon,
    LetterIcon,
    BookDetailIcon,
    ArrowRightIcon
};