import React from "react";
import { View, StyleSheet, Dimensions, ImageBackground, Image } from "react-native";
import images from '../../Resources/icons/index';

const navbarHeight = Dimensions.get('window').width * 0.08;
const AppStyle = new StyleSheet.create({
    navcontent: {
        height: navbarHeight,
        width: '100%',
        backgroundColor: '#fff',
        flexDirection: 'row',
        position: 'relative',
        justifyContent: 'center',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#454a4d73'
    },
    backIcon: {
        width: 40,
        height: 40,
        position: 'absolute',
        left: 10
    },
    navIcon: {
        width: 50,
        height: 50,
        marginLeft: 10,
        marginRight: 10,
        borderRadius: 8,
        overflow: 'hidden'
    },
    midContent: {
        flexDirection: 'row',
    }
});

const NavBar = () => {
    return(
        <View style={AppStyle.navcontent}>
            <Image style={AppStyle.backIcon} source={images.BackIcon} resizeMode="cover"></Image>
            <View style={AppStyle.midContent}>
                <Image style={AppStyle.navIcon} source={images.HatIcon} resizeMode="cover"></Image>
                <Image style={AppStyle.navIcon} source={images.LetterIcon} resizeMode="cover"></Image>
            </View>
        </View>
    );
};

export default NavBar;