import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import images from '../../Resources/icons/index';

const BreadScrumb = () => {
    return(
        <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            paddingLeft: 10
        }}>
            <View style={{width: 10, height: 10, backgroundColor: '#59c8ff', marginRight: 5}}></View>
            <Text style={{
                color: '#454a4d'
            }}>
                SGK Tieng Anh 2
            </Text>
            
            <Image style={{
                width: 10,
                height: 10,
                marginLeft: 5,
                marginRight: 5
            }} source={images.ArrowRightIcon}>

            </Image>
            <Image style={{
                width: 20,
                height: 20,
                marginLeft: 5,
                marginRight: 5
            }} source={images.BookDetailIcon}>

            </Image>
            <Text style={{
                color: '#59c8ff'
            }}>
                Sach bai hoc ky thuat so
            </Text>
        </View>
    );
};

export default BreadScrumb;